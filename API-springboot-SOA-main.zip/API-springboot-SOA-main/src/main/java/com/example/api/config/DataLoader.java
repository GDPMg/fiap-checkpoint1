package com.example.api.config;

import com.example.api.model.Pedido;
import com.example.api.repository.PedidoRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import java.time.LocalDate;
import java.util.List;

@Configuration
public class DataLoader {

    @Bean
    CommandLineRunner carregarBanco(PedidoRepository pedidoRepository) {
        return args -> {
            pedidoRepository.deleteAll();

            List<Pedido> pedidos = List.of(
                new Pedido(null, "Guilherme", LocalDate.now(), 250.0),
                new Pedido(null, "João Silva", LocalDate.now(), 150.0),
                new Pedido(null, "Maria Oliveira", LocalDate.now(), 1200.0),
                new Pedido(null, "Ana Costa", LocalDate.now(), 4500.0),
                new Pedido(null, "Carlos Souza", LocalDate.now(), 750.0)
            );

            pedidoRepository.saveAll(pedidos);

        
            long total = pedidoRepository.count();
            System.out.println("Total de pedidos no banco: " + total);
        };
    }
}
