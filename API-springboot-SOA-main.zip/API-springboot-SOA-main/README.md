﻿Endpoints e Exemplos
1. Criar um Novo Pedido
Endpoint:
POST /pedidos

Descrição:
Cria um novo pedido. O campo dataPedido é preenchido automaticamente com a data atual.

Exemplo de Requisição:

json
Copiar
{
  "clienteNome": "Fulano de Tal",
  "valorTotal": 150.0
}
Exemplo de Resposta:

json
Copiar
{
  "id": 1,
  "clienteNome": "Fulano de Tal",
  "dataPedido": "2025-03-28",
  "valorTotal": 150.0
}
2. Buscar Todos os Pedidos
Endpoint:
GET /pedidos

Descrição:
Retorna uma lista com todos os pedidos cadastrados.

Exemplo de Resposta:

json
Copiar
[
  {
    "id": 1,
    "clienteNome": "Fulano de Tal",
    "dataPedido": "2025-03-28",
    "valorTotal": 150.0
  },
  {
    "id": 2,
    "clienteNome": "Maria Silva",
    "dataPedido": "2025-03-28",
    "valorTotal": 250.0
  }
]
3. Buscar um Pedido pelo ID
Endpoint:
GET /pedidos/{id}

Descrição:
Retorna os detalhes de um pedido específico.
Exemplo: GET /pedidos/1

Exemplo de Resposta:

json
Copiar
{
  "id": 1,
  "clienteNome": "Fulano de Tal",
  "dataPedido": "2025-03-28",
  "valorTotal": 150.0
}
Resposta para ID não existente:
Caso o pedido não seja encontrado, o retorno será:

Status: 404 Not Found

4. Atualizar um Pedido
Endpoint:
PUT /pedidos/{id}

Descrição:
Atualiza os dados de um pedido existente.
Exemplo: PUT /pedidos/1

Exemplo de Requisição:

json
Copiar
{
  "clienteNome": "Fulano Atualizado",
  "valorTotal": 200.0
}
Exemplo de Resposta:

json
Copiar
{
  "id": 1,
  "clienteNome": "Fulano Atualizado",
  "dataPedido": "2025-03-28",
  "valorTotal": 200.0
}
Observação:
Se o ID informado não existir, a API retorna 404 Not Found.

5. Deletar um Pedido
Endpoint:
DELETE /pedidos/{id}

Descrição:
Remove um pedido específico do banco de dados.
Exemplo: DELETE /pedidos/1

Resposta:

Status: 204 No Content em caso de sucesso.

Caso o ID informado não exista, a API retorna 404 Not Found.